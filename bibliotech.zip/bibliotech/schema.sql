-- BiblioTech: criação do banco, tabelas e dados de exemplo
DROP DATABASE IF EXISTS bibliotech;
CREATE DATABASE bibliotech CHARACTER SET utf8mb4;
USE bibliotech;

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    telefone VARCHAR(20),
    data_cadastro DATE DEFAULT (CURRENT_DATE)
);

CREATE TABLE autores (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE livros (
    id_livro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    isbn VARCHAR(20),
    ano_publicacao INT,
    categoria VARCHAR(50)
);

CREATE TABLE livro_autor (
    id_livro INT NOT NULL,
    id_autor INT NOT NULL,
    PRIMARY KEY (id_livro, id_autor),
    FOREIGN KEY (id_livro) REFERENCES livros(id_livro),
    FOREIGN KEY (id_autor) REFERENCES autores(id_autor)
);

CREATE TABLE exemplares (
    id_exemplar INT AUTO_INCREMENT PRIMARY KEY,
    id_livro INT NOT NULL,
    status ENUM('disponivel','emprestado') DEFAULT 'disponivel',
    FOREIGN KEY (id_livro) REFERENCES livros(id_livro)
);

CREATE TABLE emprestimos (
    id_emprestimo INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_exemplar INT NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_prevista DATE NOT NULL,
    data_devolucao DATE,
    multa DECIMAL(6,2) DEFAULT 0,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_exemplar) REFERENCES exemplares(id_exemplar)
);

-- Dados de exemplo
INSERT INTO usuarios (nome, email, telefone) VALUES
 ('Ana Souza', 'ana@email.com', '44 99999-0001'),
 ('Carlos Lima', 'carlos@email.com', '44 99999-0002'),
 ('Beatriz Alves', 'bia@email.com', '44 99999-0003');

INSERT INTO autores (nome) VALUES
 ('Machado de Assis'), ('Clarice Lispector'), ('George Orwell'), ('Monteiro Lobato');

INSERT INTO livros (titulo, isbn, ano_publicacao, categoria) VALUES
 ('Dom Casmurro', '9788535911664', 1899, 'Romance'),
 ('A Hora da Estrela', '9788532508126', 1977, 'Romance'),
 ('1984', '9788535914849', 1949, 'Ficção'),
 ('Reinações de Narizinho', '9788525043115', 1931, 'Infantil');

INSERT INTO livro_autor VALUES (1,1), (2,2), (3,3), (4,4);

INSERT INTO exemplares (id_livro) VALUES (1),(1),(2),(3),(3),(4);

-- Um empréstimo atrasado para testar a tela
INSERT INTO emprestimos (id_usuario, id_exemplar, data_emprestimo, data_prevista)
VALUES (1, 1, CURDATE() - INTERVAL 15 DAY, CURDATE() - INTERVAL 8 DAY);
UPDATE exemplares SET status = 'emprestado' WHERE id_exemplar = 1;
