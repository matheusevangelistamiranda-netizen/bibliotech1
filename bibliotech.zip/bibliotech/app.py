from datetime import date, timedelta

import mysql.connector
from flask import Flask, flash, redirect, render_template, request, url_for

app = Flask(__name__)
app.secret_key = "troque-esta-chave"

MULTA_POR_DIA = 1.00  # R$ por dia de atraso
PRAZO_DIAS = 7


def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="senha",  # troque pela sua senha do MySQL
        database="bibliotech",
    )


@app.route("/")
def index():
    busca = request.args.get("q", "").strip()
    termo = f"%{busca}%"

    conn = conectar()
    cur = conn.cursor(dictionary=True)

    cur.execute(
        """
        SELECT l.id_livro, l.titulo, l.categoria, l.ano_publicacao,
               (SELECT GROUP_CONCAT(a.nome SEPARATOR ', ')
                  FROM livro_autor la
                  JOIN autores a ON a.id_autor = la.id_autor
                 WHERE la.id_livro = l.id_livro) AS autores,
               (SELECT COUNT(*) FROM exemplares e
                 WHERE e.id_livro = l.id_livro
                   AND e.status = 'disponivel') AS disponiveis,
               (SELECT COUNT(*) FROM exemplares e
                 WHERE e.id_livro = l.id_livro) AS total
          FROM livros l
         WHERE l.titulo LIKE %s
            OR l.categoria LIKE %s
            OR l.id_livro IN (
                 SELECT la.id_livro
                   FROM livro_autor la
                   JOIN autores a ON a.id_autor = la.id_autor
                  WHERE a.nome LIKE %s)
         ORDER BY l.titulo
        """,
        (termo, termo, termo),
    )
    livros = cur.fetchall()

    cur.execute("SELECT id_usuario, nome FROM usuarios ORDER BY nome")
    usuarios = cur.fetchall()

    cur.execute(
        """
        SELECT ex.id_exemplar, l.titulo
          FROM exemplares ex
          JOIN livros l ON l.id_livro = ex.id_livro
         WHERE ex.status = 'disponivel'
         ORDER BY l.titulo
        """
    )
    exemplares = cur.fetchall()

    cur.execute(
        """
        SELECT em.id_emprestimo, u.nome, l.titulo, em.data_emprestimo,
               em.data_prevista,
               em.data_prevista < CURDATE() AS atrasado
          FROM emprestimos em
          JOIN usuarios u  ON u.id_usuario = em.id_usuario
          JOIN exemplares ex ON ex.id_exemplar = em.id_exemplar
          JOIN livros l ON l.id_livro = ex.id_livro
         WHERE em.data_devolucao IS NULL
         ORDER BY em.data_prevista
        """
    )
    abertos = cur.fetchall()

    cur.close()
    conn.close()
    return render_template(
        "index.html",
        livros=livros,
        usuarios=usuarios,
        exemplares=exemplares,
        abertos=abertos,
        busca=busca,
        prazo=PRAZO_DIAS,
    )


@app.route("/emprestar", methods=["POST"])
def emprestar():
    id_usuario = request.form["id_usuario"]
    id_exemplar = request.form["id_exemplar"]

    conn = conectar()
    cur = conn.cursor()
    cur.execute(
        "SELECT status FROM exemplares WHERE id_exemplar = %s", (id_exemplar,)
    )
    linha = cur.fetchone()

    if linha is None or linha[0] != "disponivel":
        flash("Este exemplar não está disponível.", "erro")
    else:
        hoje = date.today()
        prevista = hoje + timedelta(days=PRAZO_DIAS)
        cur.execute(
            """INSERT INTO emprestimos
               (id_usuario, id_exemplar, data_emprestimo, data_prevista)
               VALUES (%s, %s, %s, %s)""",
            (id_usuario, id_exemplar, hoje, prevista),
        )
        cur.execute(
            "UPDATE exemplares SET status = 'emprestado' WHERE id_exemplar = %s",
            (id_exemplar,),
        )
        conn.commit()
        flash(f"Empréstimo registrado. Devolução até {prevista:%d/%m/%Y}.", "ok")

    cur.close()
    conn.close()
    return redirect(url_for("index"))


@app.route("/devolver/<int:id_emprestimo>", methods=["POST"])
def devolver(id_emprestimo):
    conn = conectar()
    cur = conn.cursor()
    cur.execute(
        "SELECT id_exemplar, data_prevista FROM emprestimos "
        "WHERE id_emprestimo = %s AND data_devolucao IS NULL",
        (id_emprestimo,),
    )
    linha = cur.fetchone()

    if linha is None:
        flash("Empréstimo não encontrado ou já devolvido.", "erro")
    else:
        id_exemplar, prevista = linha
        hoje = date.today()
        dias_atraso = max((hoje - prevista).days, 0)
        multa = dias_atraso * MULTA_POR_DIA

        cur.execute(
            "UPDATE emprestimos SET data_devolucao = %s, multa = %s "
            "WHERE id_emprestimo = %s",
            (hoje, multa, id_emprestimo),
        )
        cur.execute(
            "UPDATE exemplares SET status = 'disponivel' WHERE id_exemplar = %s",
            (id_exemplar,),
        )
        conn.commit()

        if multa > 0:
            flash(f"Devolvido com {dias_atraso} dia(s) de atraso. Multa: R$ {multa:.2f}.", "erro")
        else:
            flash("Livro devolvido no prazo.", "ok")

    cur.close()
    conn.close()
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
